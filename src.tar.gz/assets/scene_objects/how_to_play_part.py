from constants import ONE_SECOND
from engine.scene_object import SceneObject
from scene_objects.views.how_to_play_part_view import HowToPlayPartView


class HowToPlayPart(SceneObject):

    def __init__(self, text, images, animation_interval=ONE_SECOND):
        self._text = text
        self._images = images
        self._animation_interval = animation_interval
        super().__init__(HowToPlayPartView(self))

        self._initial_time = 0
        self._current_image_id = 0

    @property
    def text(self):
        return self._text

    @property
    def images(self):
        return self._images

    @property
    def initial_time(self):
        return self._initial_time

    @initial_time.setter
    def initial_time(self, initial_time):
        self._initial_time = initial_time

    @property
    def current_image_id(self):
        return self._current_image_id

    def update(self, current_time, player_inputs):
        self._current_image_id = int(
            (current_time - self.initial_time) / self._animation_interval) % len(self._images)

        for child in self.children:
            child.update(current_time, player_inputs)
